
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.19.2'
version = '1.19.2'
full_version = '1.19.2'
git_revision = '68752f786df542d340f25c41a8920d9b2aed66cf'
release = True

if not release:
    version = full_version
