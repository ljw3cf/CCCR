opencv_version = "4.4.0.44"
contrib = False
headless = False
ci_build = True