from distutils.core import setup

py_modules = [
 'cv2',
 'pymysql',
 'urllib'
]

setup(
    name='getProducts',
    version='0.1',
    packages=[''],
    url='',
    license='',
    author='YourName',
    author_email='',
    description=''
)

~                       
